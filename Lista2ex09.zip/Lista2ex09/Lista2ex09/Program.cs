﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p;
            char sexo;
            double a;
            double r;

            Console.WriteLine("Informe o seu Peso em KG");
            p = double.Parse(Console.ReadLine());

            Console.WriteLine("Informe o seu Sexo (feminino (F) ou Masculino (M):");
            sexo = char.Parse(Console.ReadLine());

            Console.WriteLine("Informe a sua altura em Metros");
            a = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            r = p / Math.Pow(a, 2);

            if (sexo =='m')
            {
                if (r < 20)
                {
                    Console.WriteLine("Abaixo do peso");
                }
                else 
                {
                    if (r < 25)
                    {
                        Console.WriteLine("Peso Ideal");
                    }
                    else
                    {
                        Console.WriteLine(" Acima do Peso");
                    }
                }
            }
            if (sexo =='f')
            {
                if (r <19)
                {
                    Console.WriteLine("Abaixo do Peso");
                }
                else
                {
                    if( r< 24)
                    {
                        Console.WriteLine("Peso ideal");
                    }
                    else
                    {
                        Console.WriteLine("Acima do peso");
                    }
                }
            }
        }
    }
}
