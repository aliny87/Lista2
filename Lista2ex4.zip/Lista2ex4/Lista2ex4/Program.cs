﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int b;
            int a;
            int r;

            Console.WriteLine("Digite o valor da base:");
            b = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura:");
            a = int.Parse(Console.ReadLine());

            r = b * a;

            if (r > 100)
            {
                Console.WriteLine(" a area do retangulo é {0}, logo o mesmo e grande", r);
            }
            else
                Console.WriteLine("A area do retangulo é: {0}", r);
            }

        }
    }

