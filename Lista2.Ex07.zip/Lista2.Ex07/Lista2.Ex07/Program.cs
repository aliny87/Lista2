﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2.Ex07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double r;


            Console.WriteLine(" Digite o 1º valor:");
            a = double.Parse(Console.ReadLine());

            Console.WriteLine(" Digite o 2º valor:");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine(" Digite o 3º valor:");
            c = double.Parse(Console.ReadLine());

            if(a != b)
            if(a != c)
            if(b != a)
            if(b != c)
            if(c != a)
            if(c != b)
            {
             Console.WriteLine("Voce Formou um triangulo escaleno!");               
            }
             if(a==b)
             if(b==a)
             if(c==a)
                     {
                     Console.WriteLine("Voce formou um triangulo equilatero");
                     }
               if(a!=b)
               if(c==b)
                       {
                       Console.WriteLine("Voce formou um triangulo isosceles");
                       }
               else
                if (b !=c)
                if (c ==a)
                {
                    Console.WriteLine("Voce formou um triangulo isosceles");
                }

        }
    }
}
