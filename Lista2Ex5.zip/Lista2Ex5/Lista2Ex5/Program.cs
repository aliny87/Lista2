﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double a;
            double r;

            Console.WriteLine("Digite o valor da base:");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura:");
            a = double.Parse(Console.ReadLine());

            r = b * a;

            if (a > 100)
            {
                Console.WriteLine(" A area do retangulo é {0}, Terreno grande", r);
            }
            else
            {
                Console.WriteLine(" A Area do retangulo é {0}, Terreno pequeno", r);
            }
        }
    }
}
