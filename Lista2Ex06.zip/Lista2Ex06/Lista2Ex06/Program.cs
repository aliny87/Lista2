﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;

            double p;

            double r;

            double x;

            Console.WriteLine("Vamos Clcular o seu IMC?"); 
            Console.WriteLine("Digite o seu peso atual em KG"); 
            p= double.Parse(Console.ReadLine());
            Console.WriteLine("Digite a altura em metros"); 
            a= double.Parse(Console.ReadLine());

            x = a* a;
            r = p / x;

            if (r < 20)
            {
                Console.WriteLine("Você está Abaixo do peso");
            }
            if (r > 25)
            {
                Console.WriteLine("Você está cima do peso");
            }
            if (r >= 20)
                if (r <= 25)
                {
                    Console.WriteLine("PARABENS..... Você está no Peso ideal");
                 }            
Console.ReadLine();
            }
    }
}
