﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int a;
            int b;
            int c;

            Console.Write(" Digite o 1º Valor:");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.Write(" Digite o 2º Valor:");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.Write(" Digite o 3º Valor:");
            c = int.Parse(Console.ReadLine());
            Console.WriteLine("");

           if (a == b) 
                if (a == c) 
                    Console.WriteLine("Iguais");
                else 
                    if (a > c)
                    Console.WriteLine("1º/2º maiores"); 
                    else 
                    Console.WriteLine("3º maior");
            else
            if (a == c)
                if (a > b)
                Console.WriteLine("1º/3º maiores"); 
                else 
                    Console.WriteLine("2º maior");
            else 
                if (b == c)
                   if (b > a)
                    Console.WriteLine("2º/3º maiores");
                   else 
                    Console.WriteLine("1º maior"); 
            else
                if (a > b) 
                   if (a > c)
                   Console.WriteLine("1º maior"); 
                   else 
                    Console.WriteLine("3º maior");
                else 
                    if (b > c)
                    Console.WriteLine("2º maior");
                    else 
                    Console.WriteLine("3º maior");

        }
    }
}
