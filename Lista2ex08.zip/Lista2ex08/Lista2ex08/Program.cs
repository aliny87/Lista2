﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a1;
            double b2;
            double c3;

            Console.WriteLine("Digite o 1º valor:");
            a1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2º valor:");
            b2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 3º valor:");
            c3 = double.Parse(Console.ReadLine());

            a1 = Math.Pow(a1, 2);
            b2 = Math.Pow(b2, 2);
            c3 = Math.Pow(c3, 2);

            if ((a1 + b2) == c3)
            {
                Console.WriteLine("Formou um Triangulo Retangulo");
            }
            else
            {
                if ((c3 + b2) == a1)
                {
                    Console.WriteLine("Formou um Triangulo Retangulo");
                }
                else
                {
                    if ((a1 + c3) == b2)
                    {
                        Console.WriteLine("Formou um Triangulo Retangulo");
                    }
                    else
                    {
                        Console.WriteLine("Nao Formou o triangulo retangulo");
                    }
                }


            }
        }

    }
    }

